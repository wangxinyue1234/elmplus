package xinyue.wang.ui;

public interface BusinessView extends IView{

}
