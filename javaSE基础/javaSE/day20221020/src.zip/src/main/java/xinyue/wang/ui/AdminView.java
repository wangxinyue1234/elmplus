package xinyue.wang.ui;

public interface AdminView extends IView{

    //管理员子菜单
    void showSubMenu();
}
