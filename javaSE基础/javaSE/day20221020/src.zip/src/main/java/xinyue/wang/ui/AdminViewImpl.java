package xinyue.wang.ui;

import xinyue.wang.pojo.Business;
import xinyue.wang.service.AdminService;
import xinyue.wang.service.BusinessService;

import java.sql.SQLOutput;
import java.util.Scanner;

public class AdminViewImpl implements AdminView{
    private static Scanner scanner = new Scanner(System.in);
    private AdminService adminService = new AdminService();
    private BusinessService businessService = new BusinessService();
    @Override
    public void showAll() {

    }

    @Override
    public void showSubMenu() {
        int choice = 0;
        while(true){
            System.out.println("--------------------管理员子菜单-----------------");
            System.out.println("1   信息管理");
            System.out.println("2   商家管理");
            System.out.println("3   商家列表");
            System.out.println("0   返回上级菜单");
            System.out.println("----------------------------------------------");
            System.out.print("请输入菜单编号：");
            choice = scanner.nextInt();
            switch (choice){
                case 0:
                    return;
                case 3:
                    BusinessView businessView= new BusinessViewImpl();
                    businessView.showAll();
                    System.out.print("输入要删除的id：");
                    int id = scanner.nextInt();
                    businessService.removeOne(id);
                    break;
                case 1:
                   break;
                case 2:
                    break;
                default:
                    System.out.println("输入错误请重新输入");
            }
        }
    }
    //管理员子菜单
    public static void registerNewBusiness(){
        System.out.println("请输入商店名称");
        String name = scanner.nextLine();
        System.out.println("请输商店密码");
        String pass = scanner.nextLine();
        System.out.println("请重复输入密码");
        String repass = scanner.nextLine();

    }

}
